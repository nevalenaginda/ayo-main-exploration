# Ayo Main! — UI assets & dashboard prototype

Paket ini menyediakan ilustrasi karakter terpisah dan dashboard HTML responsif. Ilustrasi bukan hasil crop dari screenshot dashboard.

## Mulai
- Buka `index.html` di browser.
- Font Fredoka dan Nunito dimuat dari Google Fonts, jadi pratinjau font memerlukan internet.
- Untuk aplikasi produksi, pindahkan file karakter ke asset folder proyek dan ganti handler `selectGame()` dengan router aplikasi.

## Aset karakter
- `assets/characters/elephant.png` — karakter gajah.
- `assets/characters/duck-bubbles.png` — bebek dan gelembung.
- `assets/characters/fruit-vegetable-trio.png` — trio apel, wortel, brokoli.
- `assets/characters/blue-car.png` — maskot mobil.
- `assets/characters/color-palette.png` — karakter palet warna.

Catatan transparansi: file karakter yang dibuat dengan latar checkerboard sudah diproses otomatis untuk menghilangkan area latar yang terhubung ke tepi. Periksa tepi halus sebelum rilis; proses otomatis bisa meninggalkan artefak kecil pada highlight atau tepi transparan.

## Tipografi
- **Fredoka 600–700** untuk logo teks, judul, dan nama kategori: bulat, ekspresif, cocok untuk UI anak.
- **Nunito 700–900** untuk teks pendamping, badge jumlah, tombol, dan teks kecil: ramah tapi lebih mudah dibaca.
- Keduanya tersedia di Google Fonts dengan lisensi SIL Open Font License. Untuk aplikasi offline/produksi, unduh font dan simpan lokal bersama lisensi OFL.

## Token desain yang direkomendasikan
- Teks utama: `#493762`
- Pink: `#FF91BF`
- Mint: `#71DDCB`
- Kuning: `#FFDA72`
- Biru: `#79BDFF`
- Ungu: `#C8A0FF`
- Hijau: `#9BE28F`
- Orange: `#FFBD79`
- Radius kartu: 24–34px
- Gap grid: 12–20px
- Gambar karakter: `object-fit: contain`, jangan gunakan `background-size: cover` atau crop yang memotong anggota tubuh.

## Lisensi dan penggunaan
Font Fredoka dan Nunito menggunakan SIL Open Font License. Aset gambar dibuat untuk paket ini; lakukan pemeriksaan visual dan legal produk yang sesuai dengan alur rilis proyek sebelum publikasi.
