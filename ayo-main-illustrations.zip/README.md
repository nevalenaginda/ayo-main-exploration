# Ayo Main! — Home Illustration Assets

Paket awal aset ilustrasi untuk 7 kartu kategori Home dan logo.

## Isi
- `public/assets/categories/*.webp`: 7 ilustrasi 3D transparan yang dioptimalkan untuk kartu Home.
- `public/assets/logo/ayo-main.webp`: logo dengan transparansi.
- `public/assets/ui/*.svg`: ikon UI sederhana.
- `masters/*.png`: versi PNG resolusi lebih tinggi untuk arsip/ekspor ulang.
- `PROMPT-IMPLEMENTASI.md`: prompt siap salin untuk AI coding agent.
- `asset-manifest.json`: daftar aset, path, dan ukuran file.

## Catatan kualitas
Gambar 3D disimpan sebagai WebP agar ringan. Sebagian aset diproses dari hasil ilustrasi dengan pemisahan latar otomatis; lakukan pemeriksaan visual pada perangkat target sebelum rilis, khususnya tepian transparansi. PNG di folder `masters` adalah salinan arsip dari aset yang disediakan di paket ini, bukan file sumber editabel ber-layer.

## Cara pakai
Salin isi folder `public/assets` ke folder `public/assets` aplikasi. Lalu ikuti `PROMPT-IMPLEMENTASI.md` untuk menghubungkan aset ke komponen kartu yang sudah ada.

Jangan mengubah layout yang sudah disetujui pada tahap integrasi gambar.
