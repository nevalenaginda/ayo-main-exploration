# Prompt Implementasi — Ayo Main! (Attempt 2: Integrasi Ilustrasi)

Integrasikan aset ilustrasi yang sudah tersedia di folder `public/assets/` ke dashboard Home Ayo Main! yang sudah ada.

## Tujuan
Mengganti placeholder gambar pada tujuh kartu kategori Home dan placeholder logo dengan ilustrasi 3D yang disediakan, tanpa merombak desain atau behavior aplikasi.

## Pemetaan aset
- Logo: `/assets/logo/ayo-main.webp`
- Hewan Lucu: `/assets/categories/animals.webp`
- Gelembung: `/assets/categories/bubbles.webp`
- Buah & Sayur: `/assets/categories/fruits-vegetables.webp`
- Kendaraan: `/assets/categories/vehicles.webp`
- Warna & Bentuk: `/assets/categories/colors-shapes.webp`
- Lagu Anak: `/assets/categories/nursery-songs.webp`
- Telepon Angka: `/assets/categories/number-phone.webp`
- Ikon UI: `/assets/ui/settings.svg`, `star.svg`, `arrow-right.svg`, `paw.svg`

## Ketentuan implementasi
1. Gunakan aset di atas apa adanya. Jangan membuat ulang, menggabungkan, atau mengganti gambar dengan emoji.
2. Pertahankan struktur komponen, route, data kategori, jumlah item, warna kartu, tipografi, badge, tombol, animasi, dan behavior scroll yang sudah disetujui.
3. Ganti hanya placeholder gambar dengan komponen gambar yang sesuai dengan framework yang sudah digunakan.
4. Untuk ilustrasi kartu gunakan `width: 100%`, `height: 100%`, `object-fit: contain`, dan posisi yang mengikuti layout kartu saat ini. Jangan gunakan `cover` jika dapat memotong karakter.
5. Pertahankan transparansi gambar agar warna latar kartu terlihat melalui area kosong.
6. Jangan mengubah ukuran atau rasio kartu untuk menyesuaikan gambar. Sisakan ruang aman di sekeliling karakter agar tidak menyentuh tepi, label, badge, atau tombol.
7. Logo harus tetap proporsional (`object-fit: contain`) dan tidak mendistorsi rasio. Jangan memasang logo jika komponen brand yang ada sudah menyediakan logo yang sama.
8. Gunakan `loading="eager"` untuk logo/ilustrasi hero yang langsung terlihat dan `loading="lazy"` untuk kartu yang berada di bawah viewport. Jangan preload seluruh aset sekaligus.
9. Sediakan `alt` yang bermakna untuk gambar informatif. Jika gambar murni dekoratif dan label kartu sudah menyampaikan nama kategori, gunakan `alt=""` agar tidak dibaca dua kali oleh screen reader.
10. Pastikan ukuran visual dan alignment konsisten antar-kartu. Jangan menambahkan latar permanen pada gambar karena warna latar sudah dimiliki kartu.
11. Pertahankan fallback/placeholder yang rapi bila file gagal dimuat.
12. Jangan menambahkan dependency baru hanya untuk menampilkan aset ini.

## Validasi
- Uji Home pada HP sempit, HP pendek, HP tinggi, dan tablet jika tersedia.
- Pastikan karakter tidak terpotong, tidak menutupi label atau badge, dan tidak menyebabkan kartu berubah tinggi.
- Pastikan scroll sampai kartu terakhir tetap berfungsi.
- Pastikan tidak ada horizontal overflow, console error, atau gambar yang dimuat berulang tanpa kebutuhan.
- Periksa ukuran file dan transparansi pada browser target.
- Jangan mengklaim pengujian yang belum dijalankan.

## Batasan
Jangan mengubah layout, warna, font, teks, jumlah kolom, behavior banner instalasi, routing, data, maupun fitur lain. Fokus hanya pada integrasi aset gambar. Laporkan file kode yang diubah dan hasil validasi setelah selesai.
